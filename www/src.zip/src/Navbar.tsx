import React, { useState, useEffect } from 'react';
import './Navbar.css';
import { useNavigate } from 'react-router-dom'; // Assuming React Router is used

const Navbar: React.FC = () => {
    const [showNavbar, setShowNavbar] = useState(true);
    const [lastScrollY, setLastScrollY] = useState(0);
    const [profilePicture, setProfilePicture] = useState<string | null>(null);
    const [showDropdown, setShowDropdown] = useState(false); // Dropdown visibility state
    const navigate = useNavigate();

    useEffect(() => {
        const handleScroll = () => {
            const currentScrollY = window.scrollY;
            setShowNavbar(currentScrollY < lastScrollY || currentScrollY === 0);
            setLastScrollY(currentScrollY);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [lastScrollY]);

    const handleSignIn = () => {
        navigate('/signin'); // Navigate to the SignIn component
    };

    const toggleDropdown = () => {
        setShowDropdown(!showDropdown);
    };

    const handleViewProfile = () => {
        navigate('/profile'); // Navigate to the Profile page
        setShowDropdown(false); // Close dropdown after navigation
    };

    const handleLogout = () => {
        // Add logout logic here
        setProfilePicture(null); // Remove profile picture on logout
        setShowDropdown(false); // Close dropdown after logout
    };

    return (
        <nav className={`navbar ${showNavbar ? 'show' : 'hide'}`}>
            <div className="navbar-logo">Arkavo</div>
            <div className="navbar-links">
                {profilePicture ? (
                    <div className="profile-container">
                        <img
                            src={profilePicture}
                            alt="Profile"
                            className="profile-picture"
                            onClick={toggleDropdown}
                        />
                        {showDropdown && (
                            <div className="dropdown-menu">
                                <button onClick={handleViewProfile}>View Profile</button>
                                <button onClick={handleLogout}>Logout</button>
                            </div>
                        )}
                    </div>
                ) : (
                    <button onClick={handleSignIn}>Sign In</button>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
