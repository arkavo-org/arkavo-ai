export interface ConversationState {
    [key: string]: string[];
}
