import React, { useState, KeyboardEvent } from 'react';
import './App.css';
import { Sidebar } from './Sidebar';
import { Chat } from './Chat';

function App() {
    const [prompt, setPrompt] = useState('');
    const [selectedPerson, setSelectedPerson] = useState('Llama'); // Default selection
    const [conversations, setConversations] = useState<{ [key: string]: string[] }>({
        Llama: [],
        'Sigmund Freud': [],
        'Bill Burns CIA': [],
        'Marlissa Smith NSA': [],
        'Albert Einstein': [],
        'Marie Curie': [],
        'Ada Lovelace': [],
        'Stephen Hawking': [],
        'Isaac Newton': []
    });

    const people = [
        'Llama',
        'Sigmund Freud',
        'Bill Burns CIA',
        'Marlissa Smith NSA',
        'Albert Einstein',
        'Marie Curie',
        'Ada Lovelace',
        'Stephen Hawking',
        'Isaac Newton',
    ];

    const handleSubmit = async () => {
        if (!prompt.trim()) return; // Prevent empty submissions

        // Add user's prompt to the conversation
        setConversations(prevConversations => ({
            ...prevConversations,
            [selectedPerson]: [...prevConversations[selectedPerson], `You: ${prompt}`]
        }));

        const jsonData = {
            model: "llama3.2",
            prompt: `${selectedPerson}: ${prompt}`, // Add context based on selected person
        };

        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(jsonData),
        });

        if (!response.body) {
            console.error('No response body');
            return;
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });

            let endOfLineIndex;
            while ((endOfLineIndex = buffer.indexOf('\n')) >= 0) {
                const line = buffer.slice(0, endOfLineIndex);
                buffer = buffer.slice(endOfLineIndex + 1);

                if (line.trim()) {
                    try {
                        const parsedLine = JSON.parse(line);
                        setConversations(prevConversations => ({
                            ...prevConversations,
                            [selectedPerson]: [...prevConversations[selectedPerson], `AI: ${parsedLine.response}`]
                        }));
                    } catch (e) {
                        console.error('Failed to parse line as JSON', e);
                    }
                }
            }
        }

        // Clear the prompt after submission
        setPrompt('');
    };

    const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    };

    const handlePersonSelect = (person: string) => {
        setSelectedPerson(person); // Update the selected person
    };

    return (
        <div className="app-container">
            <Sidebar
                people={people}
                selectedPerson={selectedPerson}
                onPersonSelect={handlePersonSelect}
            />
            <Chat
                prompt={prompt}
                setPrompt={setPrompt}
                handleSubmit={handleSubmit}
                handleKeyDown={handleKeyDown}
                conversations={conversations[selectedPerson]}
            />
        </div>
    );
}

export default App;
